<!-- Begin Masthead -->
<div id="masthead">
    <div id="mastheadleft">
        <a href="index.php" class="noborders"><img alt="MS2DBp logo" src="images/ms2db+logo.gif" onmouseover="Tip('MS2DBp Project')" onmouseout="UnTip()"/></a>
    </div>
    <div id="masterheadcenter">
        Efficient Disulfide Bond Determination Using Mass Spectrometry
    </div>
    <div id="mastheadright">
        <a href="http://www.sfsu.edu" class="noborders" target="_blank"><img alt="SFSU Logo" src="images/sfsu.jpg" onmouseover="Tip('SFSU http://www.sfsu.edu')" onmouseout="UnTip()"/></a>
    </div>
</div>
<!-- End Masthead -->