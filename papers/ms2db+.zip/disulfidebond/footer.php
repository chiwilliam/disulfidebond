<div id="footer">
    <p>MS2DB+ was partially supported by funding from the National Science Foundation (NSF) under grant IIS-0644418 (CAREER).</p>
    <p><a href="copyright.php">Copyright © 2010</a> William Murad and Rahul Singh. All Rights Reserved.</p>
</div>
<div id="footerbottom">
    <img src="images/footerbottom.png" />
</div>